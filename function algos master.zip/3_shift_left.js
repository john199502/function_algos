// Given an array, shift all values one position to the left.  Change the final position to 0. Return the changed array
// Predicted Output: shiftLeft([1,2,3,4,5]) should return [2,3,4,5,0];
var x= [1,2,3,4,5];
function shift(num){
    for (var i=0; i< num.length; i++){
        num[i] = num[i+1];
    }
    num[num.length-1] = 0;
    return num;
}
    console.log(shift(x))
   