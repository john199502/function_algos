// given some number, print "adding up" to the console and add from 1 up to that numnber and return the sum
// Predcted output: sigma(5) should return 15   (I.E: 1+2+3+4+5 =15)
var sum = [1,2,3,4,5];
function sigma(x){
   var j=0;
    for(var i=0; i< x.length; i++){
        j += x[i];
    }
    return j;
}
console.log(sigma(sum));
